package com.sotd.getid.getID;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class createItemList {

	static public boolean getIDCFG()
	{
		Writer fw = null;
		
		try
		{
			fw = new FileWriter(getID.mainDirectory + File.separator + "getid.ini");
			fw.write(itemdata.getitemdata());
		}
		catch (IOException ex)
		{
			 System.out.println( "[getID] getid.ini could not be created!" );
		}
		finally {
			  if ( fw != null )
			    try { fw.close(); } catch ( IOException e ) { e.printStackTrace(); }
			}
	return true;	
	}
}
