package com.sotd.getid.getID;

import java.io.File;

public class updateList extends getID{
	
	public static void getUpdate()
	{

		if(get_local_itemlist() != get_github_itemlist())
		{
			if(getID_file.exists())
			{
				getID_file.delete();
			}
			
			if(createConfig.createCFG())
			{
				System.out.println("[getID] getID " + getID.getID_version + " - itemList update successfully!");
			}
		}
		else
		{
			System.out.println("[getID] getID " + getID.getID_version + " - using latest itemList!");
		}

		//System.out.println(get_local_itemlist());
		//System.out.println(get_github_itemlist());
	}
	
	public static long get_local_itemlist()
		{
			File file = getID.getID_file;
			long local_itemlist_length = file.length();
			return local_itemlist_length;
		}
	
	public static long get_github_itemlist()
		{
			String str_github_itemlist = itemList.getList();
			long github_itemlist_length = str_github_itemlist.length();
			return github_itemlist_length;
		}
}