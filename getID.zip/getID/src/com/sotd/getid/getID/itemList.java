package com.sotd.getid.getID;

import java.io.InputStream; //url
import java.net.URL; //url
import java.util.Scanner; //url

public class itemList extends getID{
	
public static String getList()
		{
			InputStream is = null;
			StringBuffer stringb_itemlist = new StringBuffer();
			//necessary?..
			stringb_itemlist.delete(0, stringb_itemlist.length());
		
			try
			{
				URL url = new URL("https://github.com/SoTD/getID/raw/master/itemlist.txt");
				is = url.openStream();
			
				//delimiter, regex line break sensitive
				Scanner scanner_itemlist = new Scanner(is).useDelimiter(("./s"));
				while(scanner_itemlist.hasNext())
				{
					stringb_itemlist.append(scanner_itemlist.next());
				}
				is.close();
				}
			catch (Exception e)
			{
				System.out.println("[getID] getID " + getID_version + " - could not create item list! - HTTP!");
			}	
			return stringb_itemlist.toString();	
		}
	} 



