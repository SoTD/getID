package com.sotd.getid.getID;

import org.bukkit.Material;

/* To-Do: 
 * try-block
 * err-messages
*/ 
public class output_id {
	
	public static int get_output_id(String itemname)
	{
		int int_getid = 0;
		//err code, 0000 = no mat found
		int err = 0000;
		//some random value to init material, will be overriden
		Material material = Material.AIR;
		
		try
			{
				material = Material.valueOf(itemname);
			}
		catch (Exception ex)
			{
				return err;
			}

		 int_getid = material.getId();
		 
		 //include itemid
		 return int_getid;
	}
	
}
