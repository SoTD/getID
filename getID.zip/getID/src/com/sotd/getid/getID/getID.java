package com.sotd.getid.getID;

//java imports
import java.util.logging.Logger;
//bukkit imports
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.ChatColor;
//permissions
import com.nijiko.permissions.PermissionHandler;
import com.nijikokun.bukkit.Permissions.Permissions;

public class getID extends JavaPlugin {
	
	//latest version string
static String getID_version = "v0.3";

//logger
static Logger log = Logger.getLogger("Minecraft");

//directories
//static String mainDirectory = "plugins/getID";
//static File getID_file = new File(mainDirectory + File.separator + "getid.ini");

//itemname, stringbuilder
public String itemname;
StringBuffer stringb = new StringBuffer();

//permissions stuff
boolean UsePermissions;
public static PermissionHandler Permissions;
private static getID instance;

public static getID getInstance()
{
return instance;
}

//setup permission
private void setupPermissions()
{
Plugin test = this.getServer().getPluginManager().getPlugin("Permissions");
if (getID.Permissions == null) {
	if (test != null) {
		UsePermissions = true;
		Permissions = ((Permissions) test).getHandler();
		System.out.println("[getID] Permissions System detected. Using Permissions plugin for permissions!");
} else {
	log.info("[getID] Permissions System not detected defaulting to OP");
	UsePermissions = false;
}
}
}

//getid.id permission node check
public boolean canUseID(Player p) 
{
	if (UsePermissions) {
	return Permissions.has(p, "getid.id");
}
return p.isOp();
}

//getid.name permission node check
public boolean canUseName(Player p) 
{
	if (UsePermissions) {
	return Permissions.has(p, "getid.name");
}
return p.isOp();
}

//onCommand
public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args)
 {
	//getid command
	if (commandLabel.equalsIgnoreCase("getid"))
	{
		if (!(sender instanceof Player))
		{
			log.info("[getID] No console support!");
			return false;
		}
	
		if (canUseID((Player)sender))
		{ 
			//if no item name..or itemname longer then 3 args
			if (args.length < 1 || args.length > 3)
			{
				return false;
			}
			
			//how many entries
			int entries = args.length;

			switch(entries)
			{
			case 1:
				itemname = args[0].toLowerCase();
				break;
			case 2:
				itemname = args[0].toLowerCase() + " " + args[1].toLowerCase();
				itemname = itemname.replace(" ", "_");
				break;
			case 3:

				itemname = args[0].toLowerCase() + " " + args[1].toLowerCase() + " " + args[2].toLowerCase();
				itemname = itemname.replace(" ", "_");
				break;
			}
			
			//uppercase to match bukkit enum
			itemname = itemname.toUpperCase();
			
			int int_getid = output_id.get_output_id(itemname);
			
			if(int_getid == 0000)
			{
				sender.sendMessage("[getID] Please enter a valid itemname!");
				return false;
			}
			sender.sendMessage("[getID] The ID for the item " + ChatColor.RED + itemname + ChatColor.WHITE + " is " + ChatColor.RED + int_getid);		
		}
		else
		{
		sender.sendMessage(ChatColor.RED + "You don't have permisson to access this command!");
		}
	}		
	
	//getname command
	if (commandLabel.equalsIgnoreCase("getname"))
	{
	
		if (!(sender instanceof Player))
		{
		log.info("[getID] No console support!");
		return false;
		}
	
		if (canUseName((Player)sender))
		{ 
			//if no item name..or itemname longer then 3 args
			if (args.length < 1 || args.length > 1)
			{
				return false;
			}
			
		int id = 0;
		
		try
		{
		id = Integer.parseInt(args[0]);
		}
		catch (Exception ex)
		{
			sender.sendMessage("[getID] Please enter a valid ID!");
			return false;
		}
		
		String str_getname = output_mat.get_output_mat(id);
		
		if(str_getname == "0001")
		{
			sender.sendMessage("[getID] No item found with entered ID!");
			return false;
		}
		
		if(str_getname.contains("_"))
		{
			str_getname = str_getname.replace("_", " ");
		}
		
		sender.sendMessage("[getID] The itemname for the ID " + ChatColor.RED + id + ChatColor.WHITE + " is " + ChatColor.RED + str_getname);
		}
		else
		{
		sender.sendMessage(ChatColor.RED + "You don't have permisson to access this command!");
	 	}
	 				
} return true;
	 			
}

//onEnable void
public void onEnable()
	{
	  	setupPermissions();
	  	log.info("[getID] getID " + getID_version + " - enabled!");
	}


public void onDisable()
{
	log.info("[getID] getID v0.2 - disabled!");
}

}

