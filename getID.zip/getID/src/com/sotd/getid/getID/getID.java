package com.sotd.getid.getID;

//java imports
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
//bukkit imports
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.ChatColor;
//permissions
import com.nijiko.permissions.PermissionHandler;
import com.nijikokun.bukkit.Permissions.Permissions;


public class getID extends JavaPlugin {
	
	//latest version string
	static String getID_version = "v0.2";
	
	//logger
	static Logger log = Logger.getLogger("Minecraft");
	
	//directories
	static String mainDirectory = "plugins/getID";
	static File getID_file = new File(mainDirectory + File.separator + "getid.ini");
	
	//itemname, stringbuilder
	public String itemname;
	StringBuffer stringb = new StringBuffer();

	//permissions stuff
	boolean UsePermissions;
	public static PermissionHandler Permissions;
	private static getID instance;

public static getID getInstance()
{
return instance;
}

//setup permission
private void setupPermissions()
{
Plugin test = this.getServer().getPluginManager().getPlugin("Permissions");
	if (getID.Permissions == null) {
		if (test != null) {
			UsePermissions = true;
			Permissions = ((Permissions) test).getHandler();
			System.out.println("[getID] Permissions System detected. Using Permissions plugin for permissions!");
		} else {
			log.info("[getID] Permissions System not detected defaulting to OP");
			UsePermissions = false;
		}
		}
		}

//getid.id permission node check
public boolean canUseID(Player p) 
{
	if (UsePermissions) {
	return Permissions.has(p, "getid.id");
}
return p.isOp();
}


//onCommand
public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args)
 {
	 	if (commandLabel.equalsIgnoreCase("getid"))
	 	{
	 		if (!(sender instanceof Player))
	 		{
	 			log.info("No console support!");
	 			return false;
	 		}
	 		
	 		if (canUseID((Player)sender))
	      { 
	 			
	 			//if no item name..or itemname longer then 3 args
	 			if (args.length < 1 || args.length > 3)
	 			{
	 				return false;
	 			}
	 			else
	 			{

	 				//how many names
	 				int entries = args.length;

	 				switch(entries)
	 				{
	 				case 1:
	 					itemname = args[0].toLowerCase();
	 					break;
	 				case 2:
	 					itemname = args[0].toLowerCase() + " " + args[1].toLowerCase();
	 					itemname = itemname.replace(" ", "_");
	 					break;
	 				case 3:

	 					itemname = args[0].toLowerCase() + " " + args[1].toLowerCase() + " " + args[2].toLowerCase();
	 					itemname = itemname.replace(" ", "_");
	 					break;
	 				}

	 				//try needed
	 				try {
			
	 					//read id's
	 					BufferedReader in  = new BufferedReader(new FileReader("plugins/getID/getid.ini"));
	 					String zeile = null;
			
	 					//put into stringbuffer
	 					while ((zeile = in.readLine()) != null) {
	 						stringb.append(zeile);
	 					}
			
	 					//regex for id
	 					Matcher matcher = Pattern.compile(";\\d\\w*?" + "=" +  itemname + ";").matcher(itemList.getList());
			
	 					while(matcher.find())
	 					{
	 						if(matcher.groupCount() < 0)
	 						{
	 							return false;
	 						}
	 						//String[] splitup = matcher.group().split("=");
	 						Pattern p = Pattern.compile( "[;=]" );
	 						String[] id_split = p.split(matcher.group());
				
	 						String id_final = id_split[1];
	 						id_final = id_final.replace("_", ":");
				
	 						//itemname replace _
	 						itemname = itemname.replace("_", " ");
	 						itemname = itemname.toUpperCase();
	 						
	 						sender.sendMessage("The ID for the item " + ChatColor.RED + itemname + ChatColor.WHITE + " is: " + ChatColor.RED +  id_final);
	 						itemname = "";
	 					}
			
	 				} catch (IOException e) {
	 					e.printStackTrace();
	 				}
		
	 				//delete stringbuilder
	 				stringb.delete(0, stringb.length());
				 	}
	      	}
	 		else 
	 		{
	 			Player s = (Player)sender;
	 			s.sendMessage(ChatColor.RED + "You don't have permisson to access this command!");
		 	}
	 	}
	 	return true; 
	 	}	

//onEnable void
public void onEnable()
	{
	  	setupPermissions();
	  	log.info("[getID] getID " + getID_version + " - enabled!");
	  	
	  	
	  	if(createConfig.createCFG())
	  	{
	  		log.info("[getID] getID " + getID_version + " - itemList loaded successfully!");
	  	}
	  	
	  	updateList.getUpdate();
	}


public void onDisable()
{
	log.info("[getID] getID v0.2 - disabled!");
}

}

