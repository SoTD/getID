package com.sotd.getid.getID;

//java imports
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
//bukkit imports
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.ChatColor;
//permissions
import com.nijiko.permissions.PermissionHandler;
import com.nijikokun.bukkit.Permissions.Permissions;

public class getID extends JavaPlugin {
	
	//latest version string
static String getID_version = "v0.3";

//logger
static Logger log = Logger.getLogger("Minecraft");

//directories
static String mainDirectory = "plugins/getID";
static File getID_file_itemlist = new File(mainDirectory + File.separator + "getid.ini");

//itemname, stringbuilder
StringBuffer stringb = new StringBuffer();

String itemname;//used for getid
String str_getname;//contains itemname later
String str_getid;//contains item id later
String str_aliasid;

StringBuilder sb_itemlist = new StringBuilder();

//permissions stuff
boolean UsePermissions;
public static PermissionHandler Permissions;
private static getID instance;

public static getID getInstance()
{
return instance;
}

//setup permission
private void setupPermissions()
{
Plugin test = this.getServer().getPluginManager().getPlugin("Permissions");
if (getID.Permissions == null) {
	if (test != null) {
		UsePermissions = true;
		Permissions = ((Permissions) test).getHandler();
		System.out.println("[getID] Permissions System detected. Using Permissions plugin for permissions!");
} else {
	log.info("[getID] Permissions System not detected defaulting to OP");
	UsePermissions = false;
}
}
}

//getid.id permission node check
public boolean canUseID(Player p) 
{
	if (UsePermissions) {
	return Permissions.has(p, "getid.id");
}
return p.isOp();
}

//getid.name permission node check
public boolean canUseName(Player p) 
{
	if (UsePermissions) {
	return Permissions.has(p, "getid.name");
}
return p.isOp();
}

public void flushItemList()
{
	
	sb_itemlist = sb_itemlist.delete(0, sb_itemlist.length());
	
	Reader reader = null;
	try
	{
		reader = new FileReader(getID_file_itemlist);
		BufferedReader br = new BufferedReader(reader);
		String s = "";
		
		while((s = br.readLine()) != null)
		{ 
				sb_itemlist.append(s);
				sb_itemlist.append("\r\n");
		}
	}
	catch (IOException ex)
	{
		log.info("");
	}
	finally
	{	try
		{
			reader.close();
		}
		catch (IOException ex)
		{
			log.info("Die datei getname komme nicht geschlossen werden");
		}
	}
	
	
}
//onCommand
public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args)
 {
	//getid command
	if (commandLabel.equalsIgnoreCase("getid"))
	{
		
		
			//if no item name..or itemname longer then 3 args
			if (args.length < 1 || args.length > 3)
			{
				return false;
			}
			
			//how many entries
			int entries = args.length;

			switch(entries)
			{
			case 1:
				itemname = args[0].toLowerCase();
				break;
			case 2:
				itemname = args[0].toLowerCase() + " " + args[1].toLowerCase();
				itemname =	itemname.replace(" ", "_");
				break;
			case 3:
				itemname = args[0].toLowerCase() + " " + args[1].toLowerCase() + " " + args[2].toLowerCase();
				itemname = itemname.replace(" ", "_");
				break;
			}
			
			if(itemname.contains(" "))
			{
				itemname = itemname.replace(" ", "_");
			}
			//lowercase to match itemlist
			itemname = itemname.toLowerCase();
		
		//getting newest itemlist to sb_itemlist
		flushItemList();
	
		Matcher matcher = Pattern.compile("(.*)" + "\\=" + "\\b" + itemname + "\\b").matcher(sb_itemlist);
		while (matcher.find())
			{
				str_getid = matcher.group(1);//output
			}
		
		if(str_getid == "")
		{
			str_getid = "";
			return false;
		}
		
		if(str_getid.contains("_"))
		{
			str_getid = str_getid.replace("_", ":");
		}
		log.info(str_getid);
		str_getid = "";
		
	}		
	
	//getname command
	if (commandLabel.equalsIgnoreCase("getname"))
	{
	
		//if (!(sender instanceof Player))
		//{
		//log.info("[getID] No console support!");
		//return false;
		//}
	
		if (args.length < 1 || args.length > 1)
		{
			return false;
		}
		
		String str_args = args[0]; //die id..1 oder eben 35:1
		
		
		if(str_args.contains(":"))
		{
			str_args = str_args.replace(":", "_");
		}
		
		//getting newest itemlist to sb_itemlist
		flushItemList();
		
		Matcher matcher = Pattern.compile("\\b" + str_args + "\\b" + "\\=" + "(.*)").matcher(sb_itemlist);
		while (matcher.find())
		{
			str_getname = matcher.group(1);//output
		}
		
		if(str_getname == "")//if no result
		{
			str_getname = "";
			return false;
		}
		
		if(str_getname.contains("_"))
		{
			str_getname = str_getname.replace("_", " ");
		}
		
		str_getname = str_getname.toUpperCase();//output uppercase
		
		log.info(str_getname);//final output
		str_getname = "";
	}
 
		
	
	if (commandLabel.equalsIgnoreCase("getidadd"))
	{
		
		if (args.length < 1 || args.length > 2)
		{
			return false;
		}
		
		String alias_item = args[0];//the alias
		String original_item = args[1];//the original itemname
		
		//getting newest itemlist to sb_itemlist
		flushItemList();
		
		Matcher matcher = Pattern.compile("(.*)" + "\\=" + "\\b" + original_item + "\\b").matcher(sb_itemlist);
		while (matcher.find())
		{
			str_aliasid = matcher.group(1);//output
		}
		
		FileWriter fw = null;
		
		try
		{
		  fw = new FileWriter(getID_file_itemlist, true);
		  fw.append("\r\n");
		  fw.append(str_aliasid + "=" + alias_item);
		}
		catch ( IOException e ) {
		  System.err.println( "Konnte Datei nicht erstellen" );
		}
		finally {
		  if ( fw != null )
		    try { fw.close(); } catch ( IOException e ) { e.printStackTrace(); }
		}
		
		//getting newest itemlist to sb_itemlist
		flushItemList();
		
	}
	
		if (commandLabel.equalsIgnoreCase("getid rem"))
		{
			
		}
		
return true;	
} 
	 			

//onEnable void
public void onEnable()
	{
	  	setupPermissions();
	  	log.info("[getID] getID " + getID_version + " - enabled!");
	  	
	  	new File(mainDirectory).mkdir();
	  	
	  	if(!getID_file_itemlist.exists())
	  	{
	  		if(createItemList.getIDCFG())
	  		{
	  			log.info("[getID] getID itemlist successfully loaded!");
	  		}
	
	  	}
	}


public void onDisable()
{
	log.info("[getID] getID v0.2 - disabled!");
}

}

