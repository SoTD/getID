package com.sotd.getid.getID;

//java imports
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
//bukkit imports
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.ChatColor;
//permissions
import com.nijiko.permissions.PermissionHandler;
import com.nijikokun.bukkit.Permissions.Permissions;

public class getID extends JavaPlugin {
	
	//latest version string
static String getID_version = "v0.4";

//logger
static Logger log = Logger.getLogger("Minecraft");

//directories
static String mainDirectory = "plugins/getID";
static File getID_file_itemlist = new File(mainDirectory + File.separator + "getid.ini");
//itemname, stringbuilder
StringBuffer stringb = new StringBuffer();

String itemname;//used for getid in GETID
String str_getname;//contains the itemname in GETNAME
String str_getid;//contains item id in GETID
String str_getidadd; //contains regex match in GETIDADD
String str_getidrem; //contains regex match in GETIDREM
String str_getidadd_alias; //GETIDADD used to check if an alias has the same name as an itemname

StringBuilder sb_itemlist = new StringBuilder(); //contains the itemlist (getID.ini)

//permissions stuff
boolean UsePermissions;
public static PermissionHandler Permissions;
private static getID instance;

public static getID getInstance()
{
return instance;
}

//setup permission
private void setupPermissions()
{
Plugin test = this.getServer().getPluginManager().getPlugin("Permissions");
if (getID.Permissions == null) {
	if (test != null) {
		UsePermissions = true;
		Permissions = ((Permissions) test).getHandler();
		System.out.println("[getID] Permissions System detected. Using Permissions plugin for permissions!");
} else {
	log.info("[getID] Permissions System not detected defaulting to OP");
	UsePermissions = false;
}
}
}

//getid.id permission node check
public boolean canUseID(Player p) 
{
	if (UsePermissions) {
	return Permissions.has(p, "getid.id");
}
return p.isOp();
}

//getid.name permission node check
public boolean canUseName(Player p) 
{
	if (UsePermissions) {
	return Permissions.has(p, "getid.name");
}
return p.isOp();
}

//getid.add permission node check
public boolean canUseAdd(Player p) 
{
	if (UsePermissions) {
	return Permissions.has(p, "getid.add");
}
return p.isOp();
}

//getid.rem permission node check
public boolean canUseRem(Player p) 
{
	if (UsePermissions) {
	return Permissions.has(p, "getid.rem");
}
return p.isOp();
}

public String getItemList()
{	
	/* ############ 
	   putting the newest itemlist status into a stringbuilder
	   ############ */
	
	//delete stringbuilder every itemlist update
	sb_itemlist = sb_itemlist.delete(0, sb_itemlist.length());
	
	Reader r_getitemlist = null;
	try
	{
		r_getitemlist = new FileReader(getID_file_itemlist);
		BufferedReader br_getitemlist = new BufferedReader(r_getitemlist);
		String str_getitemlist = "";

		while((str_getitemlist = br_getitemlist.readLine()) != null)
		{ 
			sb_itemlist.append(str_getitemlist);
			sb_itemlist.append("\r\n");
		}
		
		br_getitemlist.close();
		r_getitemlist.close();
			
	}
	catch (IOException ex)
		{
			System.out.println("[getID] Error: Couldn't read the itemList!");
		}
	//contains the latest itemlist
	return sb_itemlist.toString();
}
//onCommand
public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args)
{
	/* ######################################## 
	   GETID COMMAND
	   ######################################## */
	
	if (commandLabel.equalsIgnoreCase("getid"))
		{
		
		if (!(sender instanceof Player))
		{
			log.info("[getID] No console support!");
			return false;
		}
		
		if (canUseID((Player)sender))
		{
			
		//if no item name..or itemname longer then 3 args
		if (args.length < 1 || args.length > 3)
		{
			return false;
		}
		
		//how many entries
		int entries = args.length;

		switch(entries)
		{
		case 1:
			itemname = args[0].toLowerCase();
			break;
		case 2:
			itemname = args[0].toLowerCase() + " " + args[1].toLowerCase();
			itemname =	itemname.replace(" ", "_");
			break;
		case 3:
			itemname = args[0].toLowerCase() + " " + args[1].toLowerCase() + " " + args[2].toLowerCase();
			itemname = itemname.replace(" ", "_");
			break;
		}

		if(itemname.contains(" "))
		{
			itemname = itemname.replace(" ", "_");
		}
		//lowercase to match itemlist
		itemname = itemname.toLowerCase();

		Matcher matcher = Pattern.compile("(.*)" + "\\=" + "\\b" + itemname + "\\b").matcher(getItemList());
		
		//putting each match (if more then one) into a stringbuilder
		StringBuilder sb_getid = new StringBuilder();
		sb_getid.delete(0, sb_getid.length());
		
		while (matcher.find())
		{
			sb_getid.append(matcher.group(1) + ", ");//output
		}
		
		if(sb_getid.length() <= 0)
		{
			return false;
		}
		
		str_getid = sb_getid.toString();
		
		//deleting last comma
		str_getid = str_getid.substring(0, str_getid.length() -2);

		if(str_getid == "" || str_getid == null)
		{
			str_getid = "";
			return false;
		}

		if(str_getid.contains("_"))
		{
			str_getid = str_getid.replace("_", ":");
		}
		
		//debug output
		//System.out.println(str_getid);
		
		//output the id message
		sender.sendMessage("[getID] The ID for the item " + ChatColor.RED +  itemname + ChatColor.WHITE + " is: " + ChatColor.RED + str_getid);//Output
		str_getid = "";	
		
		}
		else
		{
			sender.sendMessage(ChatColor.RED + "You don't have permisson to access this command!");
		}
}		

	
	
	/* ########################################## 
	   GETNAME COMMAND
	   ########################################## */
	if (commandLabel.equalsIgnoreCase("getname"))
	{	
		if (!(sender instanceof Player))
		{
			log.info("[getID] No console support!");
			return false;
		}
		
		if (canUseName((Player)sender))
	      {
		
		if (args.length < 1 || args.length > 1)
		{
			return false;
		}

		String str_args = args[0]; //die id..1 oder eben 35:1

		if(str_args.contains(":"))
		{
			str_args = str_args.replace(":", "_");
		}

		Matcher matcher = Pattern.compile("\\b" + str_args + "\\b" + "\\=" + "(.*)").matcher(getItemList());
		
		//putting each match (if more then one) into a stringbuilder
		StringBuilder sb_getname = new StringBuilder();
		sb_getname.delete(0, sb_getname.length());
		
		while (matcher.find())
		{
			sb_getname.append(matcher.group(1) + ", ");
			//str_getname.matcher.group(1);//output
		}
		
		//if no match
		if(sb_getname.length() <= 0)
		{
			return false;
		}
		
		//convert stringbuilder to string
		str_getname = sb_getname.toString();
		
		//if no result
		if(str_getname == "" || str_getname == null)
		{
			str_getname = "";
			return false;
		}
		
		//deleting last comma
		str_getname = str_getname.substring(0, str_getname.length() -2);

		if(str_getname.contains("_"))
		{
			str_getname = str_getname.replace("_", " ");
		}

		str_getname = str_getname.toUpperCase();//output uppercase

		//debug putput
		//System.out.println(str_getname);
		sender.sendMessage("[getID] The itemname for the ID " + ChatColor.RED +  str_args + ChatColor.WHITE + " is: " + ChatColor.RED + str_getname);//Output
		str_getname = "";
		
	      }
		else
		{
			sender.sendMessage(ChatColor.RED + "You don't have permisson to access this command!");
		}
	}
 
		
	
	
	/* ###########################################
	   GETIDADD COMMAND
	   ########################################### */
	if (commandLabel.equalsIgnoreCase("getidadd"))
	{
		
		if (!(sender instanceof Player))
		{
			log.info("[getID] No console support!");
			return false;
		}
		
		if (canUseAdd((Player)sender))
	      {
		
		
		if (args.length < 1 || args.length > 2)
		{
			return false;
		}
	
		String alias_item = args[0].toLowerCase();//the alias, lower case to match regex
		String original_id = args[1];//the original id

	
		/* ############ 
		   CHECK IF GIVEN ID IS VALID
		   ############ */
		Matcher matcher_id_exists = Pattern.compile("\\b" + original_id + "\\b" + "\\=" + "(.*)").matcher(getItemList());
		str_getidadd = "";
		
		while (matcher_id_exists.find())
		{
			str_getidadd = matcher_id_exists.group(1);//output itemname
		}
		
		//no id found message
		if(str_getidadd == "" || str_getidadd == null)
		{
			//debug output
			//System.out.println("there is no item with the id " + original_id);
			sender.sendMessage("[getID] There is no item with the ID " + ChatColor.RED + original_id + ChatColor.WHITE + "!");
			str_getidadd = "";
			return false;
		}
		
		
		/* ############ 
		   CHECK IF ALIAS ALREADY EXISTS
		   ############ */
		str_getidadd_alias = "";
		Matcher matcher_alias_exists = Pattern.compile("(.*)" + "\\=" + "\\b" + alias_item + "\\b").matcher(getItemList());
		
		while (matcher_alias_exists.find())
		{
			str_getidadd_alias = matcher_alias_exists.group(1);
		}
		
		//double alias message
		if(str_getidadd_alias.length() != 0)
		{
			//debug output
			//System.out.println("[getID] There is already a alias/item with the name " + alias_item);
			sender.sendMessage("[getID] There is already a alias/item with the name " + ChatColor.RED + alias_item);
			str_getidadd_alias = "";
			return false;
		}
		
		FileWriter fw = null;

		try
		{
			fw = new FileWriter(getID_file_itemlist, true);
			fw.append("\r\n");
			fw.append(original_id + "=" + alias_item);
			
			//debug output
			//System.out.println("[getID] The alias " + alias_item + " was successfully added!");
			sender.sendMessage("[getID] The alias " + ChatColor.RED +  alias_item + ChatColor.WHITE + " was successfully added!");
			fw.close();
		}
		catch ( IOException e ) 
		{
			//output
			System.out.println("[getID] Error: Couldn't write the itemList!");
		}
		
		str_getidadd = "";
		
	      }
		else
		{
			sender.sendMessage(ChatColor.RED + "You don't have permisson to access this command!");
		}
	}


	
	
	/* ###########################################
	   GETIDREM COMMAND
	   ########################################### */
	if (commandLabel.equalsIgnoreCase("getidrem"))
	{
		
		if (!(sender instanceof Player))
		{
			log.info("[getID] No console support!");
			return false;
		}
		
		if (canUseRem((Player)sender))
	      {
		
		if (args.length < 1 || args.length > 1)
		{
		return false;
		}
		
		//contains the alias which should be removed
		String alias_item = args[0];

		//if alias exists..
		Matcher matcher = Pattern.compile("(.*)" + "\\=" + "\\b" + alias_item + "\\b").matcher(getItemList());
		
		while (matcher.find())
		{
			str_getidrem = matcher.group(1); //output itemname
		}

		//no alias found
		if(str_getidrem == "" || str_getidrem == null)
		{	
			//debug output
			//System.out.println("[getID] No alias with the name " + alias_item + " found!");
			sender.sendMessage("[getID] No alias with the name " + ChatColor.RED +  alias_item + ChatColor.WHITE + " found!");
			return false;
		}
	
		
	    try
	    {
	    	String file = mainDirectory + File.separator + "getid.ini";
	    	File inFile = new File(file);
	    	File tempFile = new File(inFile.getAbsolutePath() + ".tmp");
	      
	    	BufferedReader br_alias = new BufferedReader(new FileReader(file));
	    	PrintWriter pw_alias = new PrintWriter(new FileWriter(tempFile));
	    	String line = null;
	      
	    	while ((line = br_alias.readLine()) != null)
	    	{
	    		if (!line.equals(str_getidrem + "=" + alias_item))
	    		{
	    			//if whitespace..
	    			if(!line.equals(""))
	    			{
	    				pw_alias.println(line);
	    				pw_alias.flush();
	    			}
	    		}
	    	}
      
	    	pw_alias.close();
	    	br_alias.close();
        
	    	//deleting latest itemlist
	    	if(inFile.exists())
	    	{
	    		inFile.delete();
	    		tempFile.renameTo(inFile);
	    	}
	    	
	    	//debug putput
	    	//System.out.println("[getID] The alias " + alias_item + " was successfully removed!");
	    	sender.sendMessage("[getID] The alias " + ChatColor.RED + alias_item + ChatColor.WHITE +  " was successfully removed!");
	    	str_getidrem = "";
	    }
	    catch (Exception ex)
	    {
    	  System.out.println("[getID] Error: Couldn't update the itemList!");
	    }	
	}
		else
		{
			sender.sendMessage(ChatColor.RED + "You don't have permisson to access this command!");
		}	
	}
	
return true;	
} 
	 			
//onEnable void
public void onEnable()
{
	setupPermissions();
	log.info("[getID] getID " + getID_version + " - enabled!");

	new File(mainDirectory).mkdir();

	if(!getID_file_itemlist.exists())
	{
		if(createItemList.getIDCFG())
		{
			log.info("[getID] getID itemlist successfully loaded!");
	  	}
		
	}
}


public void onDisable()
{
	log.info("[getID] getID " + getID_version + " - disabled!");
}

}

