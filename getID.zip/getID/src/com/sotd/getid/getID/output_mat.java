package com.sotd.getid.getID;

import org.bukkit.Material;

/* To-Do: 
 * try-block
 * err-messages
*/ 
public class output_mat {

	//id input, mat output
	public static String get_output_mat(int id)
	{
		String str_getmat = "";
		//err code 0001 = no id found
		String err = "0001";
		
		Material output_mat = Material.getMaterial(id);
		
		try
			{
				str_getmat = output_mat.toString();
			}
		catch (Exception ex)
			{
				return err;
			}
		//include materialname
		return str_getmat;
	}
}
