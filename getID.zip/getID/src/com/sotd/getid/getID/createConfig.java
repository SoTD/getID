package com.sotd.getid.getID;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class createConfig extends getID{
	

public static boolean createCFG()
	{
	
	new File(getID.mainDirectory).mkdir();
	if(!getID_file.exists())
			{ 
				Writer fw  = null;
				
				try
				{
					fw = new FileWriter(getID.mainDirectory + File.separator + "getid.ini");
					fw.write(itemList.getList());
					//fw.append(System.getProperty("line.separator"));
					fw.close();
				}
				catch (IOException e)
				{
					System.out.println("[getID] getID " + getID_version + " - could not create item list! - local");
					return false;
				}
			} return true;
	  				}
		}
